const dropdownTrigger = () => {
    $(".dropdown-trigger").dropdown({ constrainWidth: false });
};

export default { dropdownTrigger };
