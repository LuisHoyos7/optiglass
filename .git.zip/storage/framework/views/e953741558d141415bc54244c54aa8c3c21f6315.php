

<?php $__env->startSection('content'); ?>

	
			<div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">	
				<div class="container">
					<div class="row">
						<div class="col s10 m6 l6">
							<h5 class="breadcrumbs-title mt-0 mb-0">Subestados</h5>
						</div>
					</div>
				</div>
			</div>
			
			<div class="col s12">
				<div class="container">
					<div class="section">
						
						<div class="row">
							<div class="col s12">
								<div id="validations" class="card card-tabs">
									<div class="card-content">
									
										<div class="row">
											<div class="col s12">
											  <table id="data-table-simple" class="display nowrap" width="100%">
												<thead>
												  <tr>
													<th></th>
													<th>Descripcion estado</th>
													<th>Código</th>
													<th>Descripción</th>
													<th>Estado</th>
												  </tr>
												</thead>
												
											  </table>
											</div>
										</div>

										<div class="row">
											<div class="input-field col s12">
												<button class="btn waves-effect waves-light right gradient-45deg-indigo-purple gradient-shadow sidenav-trigger" data-target="slide-out-right" type="button">Nuevo
													<i class="material-icons right">note_add</i>
												</button>
											</div>
										</div>
										
									</div>
								</div>						
							</div>
						</div>
						
						<!-- START RIGHT SIDEBAR NAV -->
						<aside id="right-sidebar-nav">
							<div id="slide-out-right" class="slide-out-right-sidenav sidenav rightside-navigation">
						  <div class="row">
							 <div class="slide-out-right-title">
								<div class="col s12 border-bottom-1 pb-0 pt-1">
								   <div class="row">
									  <div class="col s2 pr-0 center">
										 <i class="material-icons vertical-text-middle"><a href="#" class="sidenav-close">clear</a></i>
									  </div>
									  <div class="col s10 pl-0">
										 <h5>Nuevo</h5>
									  </div>
								   </div>
								</div>
							 </div>
							 <div class="slide-out-right-body">
								<div class="col s12">
										
									<form class="formValidate" id="formSubestadoNuevo" method="post">
																							
											<?php echo e(csrf_field()); ?>	
											<div class="col s12">
												<label for="cmbCodigoEstadoNuevo">Descripción estado</label>
												<select class="error browser-default" id="cmbCodigoEstadoNuevo" name="codigoEstado" data-error=".errorTxt1">
													
												</select>
												<div class="input-field">
													<div class="errorTxt1"></div>
												</div>
											</div>

											<div class="input-field col s12">
												<label for="txtCodigoNuevo">Código</label>
												<input id="txtCodigoNuevo" name="codigo" type="text" maxlength="2" data-error=".errorTxt2" placeholder="">
												<div class="errorTxt2"></div>
											</div>
										
											<div class="input-field col s12">
												<label for="txtDescripcionNuevo">Descripción</label>
												<input type="text" name="descripcion" id="txtDescripcionNuevo" maxlength="100" data-error=".errorTxt3" placeholder="">
												<div class="errorTxt3"></div>
											</div>

											<div class="col s12">
												<label for="cmbEstadoNuevo">Estado</label>
												<select class="error browser-default" id="cmbEstadoNuevo" name="estado" data-error=".errorTxt4">
													<option value="" disabled selected>Seleccione</option>
													<option value="A">Activo</option>
													<option value="I">Inactivo</option>
												</select>
												<div class="input-field">
													<div class="errorTxt4"></div>
												</div>
											</div>

											<div class="input-field col s12">
												<button class="btn waves-effect waves-light right submit gradient-45deg-indigo-purple gradient-shadow" type="submit" name="action">Guardar
													<i class="material-icons right">save</i>
												</button>
											</div>
										
									</form>
										
							   </div>
							</div>
						 </div>
					  </div>
					</aside>
					<!-- END RIGHT SIDEBAR NAV -->

					<!-- START RIGHT SIDEBAR NAV -->
						<aside id="right-sidebar-nav-">
							<div id="slide-out-right-second" class="slide-out-right-sidenav sidenav rightside-navigation">
						  <div class="row">
							 <div class="slide-out-right-title">
								<div class="col s12 border-bottom-1 pb-0 pt-1">
								   <div class="row">
									  <div class="col s2 pr-0 center">
										 <i class="material-icons vertical-text-middle"><a href="#" class="sidenav-close">clear</a></i>
									  </div>
									  <div class="col s10 pl-0">
										 <h5>Editar</h5>
									  </div>
								   </div>
								</div>
							 </div>
							 <div class="slide-out-right-second-body">
								<div class="col s12">
										
									<form class="formValidate" id="formSubestadoEditar" method="put">
																							
											<?php echo e(csrf_field()); ?>	
											<div class="col s12">
												<label for="cmbCodigoEstadoEditar">Descripción estado</label>
												<select class="error browser-default" id="cmbCodigoEstadoEditar" name="codigoEstado" data-error=".errorTxt5">
													
												</select>
												<div class="input-field">
													<div class="errorTxt5"></div>
												</div>
											</div>
											
											<div class="input-field col s12">
												<label for="txtCodigoEditar">Código</label>
												<input readonly id="txtCodigoEditar" name="codigo" type="text" maxlength="2" data-error=".errorTxt6" placeholder="">
												<div class="errorTxt6"></div>
											</div>
										
											<div class="input-field col s12">
												<label for="txtDescripcionEditar">Descripción</label>
												<input type="text" name="descripcion" id="txtDescripcionEditar" maxlength="100" data-error=".errorTxt7" placeholder="">
												<div class="errorTxt7"></div>
											</div>

											<div class="col s12">
												<label for="cmbEstadoEditar">Estado</label>
												<select class="error browser-default" id="cmbEstadoEditar" name="estado" data-error=".errorTxt8">
													<option value="" disabled selected>Seleccione</option>
													<option value="A">Activo</option>
													<option value="I">Inactivo</option>
												</select>
												<div class="input-field">
													<div class="errorTxt8"></div>
												</div>
											</div>

											
											<div class="input-field col s12">
												<button class="btn waves-effect waves-light right submit gradient-45deg-indigo-purple gradient-shadow" type="submit" name="action">Guardar
													<i class="material-icons right">save</i>
												</button>
											</div>
										
									</form>
										
							   </div>
							</div>
						 </div>
					  </div>
					</aside>
					<!-- END RIGHT SIDEBAR NAV -->
						
					</div>	
				</div>
			</div>
		

	<!-- scripts -->
	<script src="app-assets/vendors/data-tables/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/data-tables/extensions/responsive/js/dataTables.responsive.min.js" type="text/javascript"></script>
	<script src="js/subestados.js" type="module"></script>
    <script src="app-assets/js/scripts/data-tables.js" type="text/javascript"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/subohatn/app.optiglasslatam.com/resources/views/subestados.blade.php ENDPATH**/ ?>