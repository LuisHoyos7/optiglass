<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Liquidación</title>
  </head>

<body>
  <?php $__currentLoopData = $liquidaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liquidacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
  <h4>PROMOTOR: <?php echo e($liquidacion->nombrePromotor); ?></h4>
  <table style="width: 100%;border-collapse: collapse;text-align: center;">
  	<thead>
	  <tr>
		<th style="border: solid;">FECHA INICIO</th>
		<th style="border: solid;">FECHA FIN</th>
		<th style="border: solid;">GANANCIA</th>
		<th style="border: solid;">PRESTAMO</th>
		<th style="border: solid;">SALDO A PAGAR</th>
	  </tr>
	</thead>
	<tbody>
		    <tr>
		    	<td style="border: solid;"><?php echo e($liquidacion->fechaInicio); ?></td>
			    <td style="border: solid;"><?php echo e($liquidacion->fechaFin); ?></td>
			    <td style="border: solid;"><?php echo e($liquidacion->ganancia); ?></td>
			    <td style="border: solid;"><?php echo e($liquidacion->prestamo); ?></td>
			    <td style="border: solid;"><?php echo e($liquidacion->ganancia - $liquidacion->prestamo); ?></td>
			</tr>
	</tbody>
	<tfoot>
		<tr>
	    	<td></td>
		    <td></td>
		    <td></td>
		    <td style="border: solid; font-weight: bold;">SUBTOTAL</td>
		    <td style="border: solid;">$ <?php echo e($liquidacion->ganancia - $liquidacion->prestamo); ?></td>
		</tr>
		<tr>
	    	<td></td>
		    <td></td>
		    <td></td>
		    <td style="border: solid;font-weight: bold;">ERRORES</td>
		    <td style="border: solid;">$ <?php echo e($liquidacion->valorErrores); ?></td>
		</tr>
		<tr>
	    	<td></td>
		    <td></td>
		    <td></td>
		    <td style="border: solid;font-weight: bold;">TOTAL</td>
		    <td style="border: solid;">$ <?php echo e($liquidacion->total); ?></td>
		</tr>
	</tfoot>
  </table>
  <?php if($errores != null): ?>
  <h5>LISTA DE ERRORES</h5>
  <table style="width: 100%;border-collapse: collapse;text-align: center;">
  	<thead>
  		<tr>
	  		<th style="border: solid;">FECHA</th>
	  		<th style="border: solid;">CONSECUTIVO</th>
	  		<th style="border: solid;">BRIGADA</th>
	  		<th style="border: solid;">ERROR</th>
	  	</tr>
  	</thead>
  	<tbody style="font-size: 12px">
		<?php $__currentLoopData = $errores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($error->liquidacion == $liquidacion->id): ?>	
  		<tr>
	    	<td style="border: solid;"><?php echo e($error->fecha); ?></td>
		    <td style="border: solid;"><?php echo e($error->consecutivo); ?></td>
		    <td style="border: solid;"><?php echo e($error->brigada); ?></td>
		    <td style="border: solid;"><?php echo e($error->error); ?></td>
		</tr>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  	</tbody>
  </table>
  <P style="text-align: center;">------------------------------------------------------------------------------------------------------------------</p>
  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php if($resumen != null): ?>
  <h4>Resumen</h4>
  <table style="width: 100%;border-collapse: collapse;text-align: center;">
  	<thead>
	  <tr>
		<th style="border: solid;">FECHA INICIO</th>
		<th style="border: solid;">FECHA FIN</th>
		<th style="border: solid;">GANANCIA</th>
		<th style="border: solid;">PRESTAMO</th>
		<th style="border: solid;">SALDO A PAGAR</th>
	  </tr>
	</thead>
	<tbody>
		    <tr>
		    	<td style="border: solid;"><?php echo e($resumen->fechaInicio); ?></td>
			    <td style="border: solid;"><?php echo e($resumen->fechaFin); ?></td>
			    <td style="border: solid;"><?php echo e($resumen->ganancia); ?></td>
			    <td style="border: solid;"><?php echo e($resumen->prestamo); ?></td>
			    <td style="border: solid;"><?php echo e($resumen->ganancia - $resumen->prestamo); ?></td>
			</tr>
	</tbody>
	<tfoot>
		<tr>
	    	<td></td>
		    <td></td>
		    <td></td>
		    <td style="border: solid; font-weight: bold;">SUBTOTAL</td>
		    <td style="border: solid;">$ <?php echo e($resumen->ganancia - $resumen->prestamo); ?></td>
		</tr>
		<tr>
	    	<td></td>
		    <td></td>
		    <td></td>
		    <td style="border: solid;font-weight: bold;">ERRORES</td>
		    <td style="border: solid;">$ <?php echo e($resumen->valorErrores); ?></td>
		</tr>
		<tr>
	    	<td></td>
		    <td></td>
		    <td></td>
		    <td style="border: solid;font-weight: bold;">TOTAL</td>
		    <td style="border: solid;">$ <?php echo e($resumen->total); ?></td>
		</tr>
	</tfoot>
  </table>
  <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\optiglass\resources\views/reports/liquidacion.blade.php ENDPATH**/ ?>