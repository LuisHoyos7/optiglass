<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoLente extends Model
{
     protected $table = 'tipos_lentes';
     public $timestamps = false;

}
