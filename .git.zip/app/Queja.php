<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Queja extends Model
{
     protected $table = 'quejas';
     public $timestamps = false;
}
