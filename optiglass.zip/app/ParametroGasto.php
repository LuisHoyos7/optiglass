<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ParametroGasto extends Model
{
     protected $table = 'parametros_gastos';
     public $timestamps = false;

}
